package com.Shivaa.OrderService.Service;

import com.Shivaa.OrderService.Common.Payment;
import com.Shivaa.OrderService.Common.TransactionRequest;
import com.Shivaa.OrderService.Common.TransactionResponse;
import com.Shivaa.OrderService.Model.Order;
import com.Shivaa.OrderService.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class OrderService {
@Autowired
    private RestTemplate template;
    @Autowired
private OrderRepository orderRepository;
    public TransactionResponse bookOrderData(TransactionRequest request) {
        String response="";
        Order order = request.getOrder();
        Payment payment = request.getPayment();
        payment.setOrderId(order.getOrder_Id());
        payment.setAmount(order.getOrder_Price());
        //payment.setPaymentStatus();
       Payment paymentResponse = template.postForObject("http://payment-service/app/home/payment",payment, Payment.class);

       response=paymentResponse.getPaymentStatus().equals("success")?"payment processing is success and order is placed":"There is a failure in order api";
       orderRepository.save(order);
        return new TransactionResponse(order.getOrder_Quantity(),paymentResponse.getAmount(),paymentResponse.getTransactionId(),response);
    }

    public List<Order> getOrderData() {
        return orderRepository.findAll();

    }
}
