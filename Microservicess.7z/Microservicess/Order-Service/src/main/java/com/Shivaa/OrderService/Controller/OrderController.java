package com.Shivaa.OrderService.Controller;

import com.Shivaa.OrderService.Common.Payment;
import com.Shivaa.OrderService.Common.TransactionRequest;
import com.Shivaa.OrderService.Common.TransactionResponse;
import com.Shivaa.OrderService.Model.Order;
import com.Shivaa.OrderService.Service.OrderService;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/app/home")
public class OrderController {
    @Autowired
    private OrderService orderService;

    @PostMapping("/bookOrder")
    @CircuitBreaker(name="hello",fallbackMethod="paymentFallback")
    public TransactionResponse bookOrder(@RequestBody TransactionRequest request){

        return orderService.bookOrderData(request);
    }

    public TransactionResponse paymentFallback(Exception e){


        return new TransactionResponse(1212,30000,1221344,"Ordered Confirmed please pay the amount on delivery time!!!");

    }


    @GetMapping("/getOrderDetails")
    public List<Order> getDetails(){
        return orderService.getOrderData();
    }
}
