package com.Shivaa.OrderService.Model;

import lombok.*;

import javax.persistence.*;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@Table(name = "Orders")
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int order_Id;
    private String order_Name;
    private int order_Quantity;
    private Double order_Price;
}
