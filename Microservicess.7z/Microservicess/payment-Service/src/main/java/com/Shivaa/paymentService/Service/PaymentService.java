package com.Shivaa.paymentService.Service;

import com.Shivaa.paymentService.Model.Payment;
import com.Shivaa.paymentService.Repository.PaymentRepository;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.*;

import java.util.Random;
import java.util.UUID;

@Service
public class PaymentService {
@Autowired
private PaymentRepository paymentRepository;

    public Payment getPaymentDetails(Payment payment) {

        payment.setPaymentStatus(paymentProcessing());
        payment.setTransactionId(UUID.randomUUID().toString().hashCode());
       return paymentRepository.save(payment);
    }

    private String paymentProcessing() {
        return new Random().nextBoolean()?"success":"Fail";
    }

}
