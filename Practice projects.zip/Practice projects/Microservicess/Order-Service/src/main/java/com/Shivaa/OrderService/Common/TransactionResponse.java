package com.Shivaa.OrderService.Common;

import com.Shivaa.OrderService.Model.Order;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class TransactionResponse {
    private int quantity;
    private  double amount;
    private int transactionId;
    private String message;
}
