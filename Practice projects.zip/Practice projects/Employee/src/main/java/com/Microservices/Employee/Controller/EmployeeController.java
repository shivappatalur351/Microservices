package com.Microservices.Employee.Controller;

import com.Microservices.Employee.Model.Employee;
import com.Microservices.Employee.Repository.EmployeeRepo;
import com.Microservices.Employee.Services.EmployeeService;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/home")
public class EmployeeController {

    @Getter
    @Setter
    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private EmployeeRepo employeeRepo;

    @PostMapping("/Employee")
    public Employee create(@RequestBody Employee employee){
       return employeeService.add(employee);


    }

    @GetMapping("/Employee")
    public List<Employee> Get(){
        return employeeService.getData();
    }

}
