package com.Microservices.Employee.Services;

import com.Microservices.Employee.Model.Employee;
import com.Microservices.Employee.Repository.EmployeeRepo;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeService {

    @Getter
    @Setter
    @Autowired
    private EmployeeRepo employeeRepo;

    public Employee add(Employee employee) {
    return employeeRepo.save(employee);
    }

    public List<Employee> getData() {
        return employeeRepo.findAll();
    }
}
