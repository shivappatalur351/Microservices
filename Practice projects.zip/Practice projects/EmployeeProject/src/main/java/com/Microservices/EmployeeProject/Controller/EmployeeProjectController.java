package com.Microservices.EmployeeProject.Controller;

import com.Microservices.EmployeeProject.Model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController

@RequestMapping("/home/microservices")
public class EmployeeProjectController {
    @Autowired
    RestTemplate restTemplate;
    EmployeeProject employeeProject=new EmployeeProject();
    @GetMapping("/getData")
    public EmployeeProject get(){
        LIstOfEmployee employee=restTemplate.getForObject("http://localhost:8082/home/Employee", LIstOfEmployee.class);
        ListOfProjects project=restTemplate.getForObject("http://localhost:8083/home/project/get", ListOfProjects.class);
        employeeProject.setLIstOfEmployee(employee);
        employeeProject.setListOfProjects(project);
        return employeeProject;
    }

}
