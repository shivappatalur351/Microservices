package com.Microservices.EmployeeProject.Model;

import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Getter
@Setter
public class Employee {

    private Long employee_Id;

    private String employee_Name;

    private String employee_Location;

}
