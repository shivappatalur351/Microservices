package com.Microservices.EmployeeProject.Model;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Data
public class EmployeeProject {

   LIstOfEmployee lIstOfEmployee;
   ListOfProjects listOfProjects;

}
