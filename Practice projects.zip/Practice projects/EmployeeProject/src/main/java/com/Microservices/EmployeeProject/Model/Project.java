package com.Microservices.EmployeeProject.Model;

import lombok.*;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class Project {


    private Long project_Id;
    private String project_Name;
}
