package com.Microservices.Project.ProjectService;

import com.Microservices.Project.Model.Project;
import com.Microservices.Project.ProjectRepo.ProjectRepo;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProjectService {

    @Getter
    @Setter
    @Autowired
    private ProjectRepo projectRepo;
    public Project save(Project project) {
        return projectRepo.save(project);
    }

    public List<Project> getData() {
        return projectRepo.findAll();
    }
}
