package com.Microservices.Project.ProjectController;

import com.Microservices.Project.Model.Project;
import com.Microservices.Project.ProjectService.ProjectService;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/home/project")
public class ProjectController {

    @Getter
    @Setter
    @Autowired
    private ProjectService projectService;

    @PostMapping("/add")
    public Project create(@RequestBody Project project){
        return projectService.save(project);
    }

    @GetMapping("/get")
    public List<Project> getData(){
        return projectService.getData();
    }
}
