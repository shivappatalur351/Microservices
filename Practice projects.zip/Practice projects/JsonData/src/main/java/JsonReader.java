import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
public class JsonReader {

    public static void main(String[] args) {
        System.out.println("WelCOme to thbs");
        JSONParser jsonParser=new JSONParser();
        try (FileReader file=new FileReader("C:\\Users\\shivappa_talur\\Documents\\test\\example.json")){

            Object obj=jsonParser.parse(file);

            JSONArray jsonArray=(JSONArray) obj;
            System.out.println(jsonArray);

            //jsonArray.forEach(emp-> parseEmployeeObject(JSONObject) emp);
        }
        catch (IOException e){
            e.printStackTrace();
        }

        catch (org.json.simple.parser.ParseException e) {
            throw new RuntimeException(e);
        }
    }
}
